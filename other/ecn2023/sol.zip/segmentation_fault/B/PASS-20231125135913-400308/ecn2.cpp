#include <iostream>
#include <stack>
#include <string>
#include <vector>
#include <map>
#include <set>

using namespace std;

int main()
{
	int n;
	cin >> n;
	vector<int>preturi(n);
	set<int>a[4];
	for (int& it : preturi)
		cin >> it;
	for (int i = 0; i < n; i++)
	{
		int c;
		cin >> c;
		a[c].insert(preturi[i]);
	}

	for (int i = 0; i < n; i++)
	{
		int c;
		cin >> c;
		a[c].insert(preturi[i]);
	}

	int m;
	cin >> m;
	for (int i = 0; i < m; i++)
	{
		int c;
		cin >> c;
		if (a[c].empty())
		{
			cout << "-1";
			if (i != m - 1)
				cout << " ";
			continue;
		}
		int sol = *(a[c].begin());

		cout << sol;
		if (i != m - 1)
			cout << " ";

		for (int j = 1; j <= 3; j++)
		{
			if (a[j].count(sol) > 0)
				a[j].erase(sol);
		}
	}
	cout << "\n";
}