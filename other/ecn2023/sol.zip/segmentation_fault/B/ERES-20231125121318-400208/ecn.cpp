#include <iostream>
#include <stack>
#include <string>
#include <vector>
#include <map>
#include <set>

using namespace std;


struct Obiect{
	int pret;
	int colors[2];
};

int main()
{
	int n;
	cin >> n;

	vector<Obiect>a(n + 1);

	for (int i = 0; i < n; i++)
		cin >> a[i].pret;
	
	for (int i = 0; i < n; i++)
		cin >> a[i].colors[0];

	for (int i = 0; i < n; i++)
		cin >> a[i].colors[1];
	
	map<int, Obiect>color_map[4];
	
	for (const auto &obj : a)
	{
		for (int j = 0; j < 2; j++)
		{
			color_map[obj.colors[j]][obj.pret] = obj;
		}
	}

	int m;
	cin >> m;
	for (int i = 0; i < m; i++)
	{
		int x;
		cin >> x;
		if (color_map[x].empty())
		{
			cout << "-1";
			if (i != m - 1)
				cout << " ";
			continue;
		}
		Obiect obj = color_map[x].begin()->second;
		for (int* color = obj.colors; color < obj.colors + 2; color++)
		{
			color_map[*color].erase(obj.pret);
		}
		cout << obj.pret;
		if (i != m - 1)
			cout << " ";
	}
	cout << '\n';
}