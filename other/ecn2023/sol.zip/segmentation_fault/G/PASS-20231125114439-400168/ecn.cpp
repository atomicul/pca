#include <iostream>
#include <stack>
#include <string>
#include <vector>

using namespace std;

string s;

int main()
{
	stack<int>st;

	while (!cin.eof())
	{
		cin >> s;
		if (s == "TITKOS_E")
		{
			cout << st.top()<<'\n';
			return 0;
		}
		if (s.back() == 'P')
		{
			int nr;
			cin >> nr;
			st.push(nr);
		}
		else
		{
				int nr1 = st.top();
				st.pop();
				int nr2 = st.top();
				st.pop();

				if (s.back() == 'A')
					st.push(nr1 + nr2);
				else
					st.push(nr1 - nr2);
		}
	}
}


