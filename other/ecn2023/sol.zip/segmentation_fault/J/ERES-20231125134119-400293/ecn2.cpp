#include <iostream>
#include <unordered_map>
#include <unordered_set>
#include <string>
#include <algorithm>
#include <vector>
#include<map>

using namespace std;

using Person = pair<string, string>;

int main()
{
	int n;
	cin >> n;

	unordered_map<string, vector<Person>>my_map;
	unordered_map<string,string>adoptat;

	for (int i = 0; i < n; i++)
	{
		string cod,adn,adop,nume;
		cin >> cod >> adn >> adop;
		getline(cin, nume);
		///cin.ignore();///?
		if (adop == "A" && adoptat.count(adn) == 0)
			adoptat[adn] = cod;
		my_map[adn].push_back({ cod,nume });
	}

	bool first_print = true;

	map<int,vector<Person>> groups;

	for (const auto& x : adoptat)
	{
		const string& adn = x.first;
		const string& cod = x.second;
		
		auto& objects = my_map[adn];

		if (objects.size() == 2 || objects.size() == 3)
		{
			sort(objects.begin(), objects.end(), [](const pair<string, string>& a, const pair<string, string>& b) {
				return stoi(a.first) < stoi(b.first);
				});
			groups[stoi(cod)] = move(objects);
		}
	}

	for (auto it = groups.begin();it != groups.end();it++)
	{
		for (const auto& obj : it->second)
			cout << obj.first << " " << obj.second << "\n";
		auto last = groups.end();
		last--;
		if (it != last)
			cout << "\n";
	}

}