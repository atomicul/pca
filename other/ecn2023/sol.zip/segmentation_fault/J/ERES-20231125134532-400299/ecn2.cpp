#include <iostream>
#include <unordered_map>
#include <unordered_set>
#include <string>
#include <algorithm>
#include <vector>

using namespace std;

using Person = pair<string, string>;

int main()
{
	int n;
	cin >> n;

	unordered_map<string, vector<Person>>map;
	unordered_set<string>adoptat;

	for (int i = 0; i < n; i++)
	{
		string cod, adn, adop, nume;
		cin >> cod >> adn >> adop;
		getline(cin, nume);
		///cin.ignore();///?
		if (adop == "A")
			adoptat.insert(adn);
		map[adn].push_back({ cod,nume });
	}

	bool first_print = true;

	vector<vector<Person>> groups;

	for (const auto& adn : adoptat)
	{
		auto& objects = map[adn];

		if (objects.size() == 2 || objects.size() == 3)
		{
			sort(objects.begin(), objects.end(), [](const pair<string, string>& a, const pair<string, string>& b) {
				return stoi(a.first) < stoi(b.first);
				});
			groups.push_back(move(objects));
		}
	}
	sort(groups.begin(), groups.end(), [](const vector<Person>& a, const vector<Person>& b) {
		return stoi(a.back().first) < stoi(b.back().first);
		});


	for (int i = 0; i < groups.size(); i++)
	{
		for (const auto& obj : groups[i])
			cout << obj.first << " " << obj.second << "\n";
		if (i != groups.size() - 1)
			cout << "\n";
	}

}