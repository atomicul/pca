#include <iostream>
#include<vector>
#include<string>
#include<map>
#include<unordered_map>
#include<algorithm>
#include<utility>
using namespace std;
#define ll long long
struct tc {
    ll cost;
    ll face;
    ll back;
    bool exist;

};
int comp(tc a, tc b) {
    return a.cost < b.cost;
}
tc tablecloths[200005];
ll n, q;
int main()
{
    ios_base::sync_with_stdio(NULL), cin.tie(NULL), cout.tie(NULL);
    cin >> n;
    
    for (ll i = 0; i < n; i++) {
        ll x;
        cin >> x;
        tablecloths[i].cost = x;
        
    }
    for (ll i = 0; i < n; i++) {
        ll x;
        cin >> x;
        tablecloths[i].face = x;

    }for (ll i = 0; i < n; i++) {
        ll x;
        cin >> x;
        tablecloths[i].back = x;
        tablecloths[i].exist = true;

    }
    sort(tablecloths, tablecloths+n, comp);
    cin >> q;
    while (q--) {
        ll x;
        cin >> x;
        for (ll i = 0; i < n;i++) {
            if (tablecloths[i].exist==true&&(tablecloths[i].face == x || tablecloths[i].back == x) ) {
                cout << tablecloths[i].cost<<" ";
                tablecloths[i].exist = false;
                break;
            }
        }
    }

    return 0;
}
