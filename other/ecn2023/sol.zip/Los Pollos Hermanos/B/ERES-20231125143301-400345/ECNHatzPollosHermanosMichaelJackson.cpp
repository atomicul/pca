#include <iostream>
#include<vector>
#include<string>
#include<map>
#include <set>
#include<unordered_map>
#include<algorithm>
#include<utility>
#include<fstream>
#include<stack>
using namespace std;
ifstream in("citire.in");
ofstream out("afisare.out");
#define ll long long

int main()
{
    ios_base::sync_with_stdio(NULL), cin.tie(NULL), cout.tie(NULL);
    ll n;
    cin >> n;
    vector<pair<long long, pair<long long, long long>>>v(n);
    unordered_map<long long, bool>bought;
    for (long long i = 0; i < n; i++) {
        cin >> v[i].first;
        bought[v[i].first] = false;
    }
    vector<stack<long long>>colors(4);
    for (long long i = 0; i < n; i++) {
        long long x;
        cin >> x;
        v[i].second.first = x;       
    }
    for (long long i = 0; i < n; i++) {
        long long x;
        cin >> x;
        v[i].second.second = x;
    }
    sort(v.begin(), v.end());
    for (long long i = n - 1; i >= 0; i--) {
        bought[v[i].first] = false;
        colors[v[i].second.first].push(v[i].first);
        colors[v[i].second.second].push(v[i].first);
    }
    long long m;
    cin >> m;
    while (m--) {
        long long customer;
        cin >> customer;
        while (colors[customer].empty() == false && bought[colors[customer].top()] == true) {
            colors[customer].pop();
        }
        if (colors[customer].empty() == true)out <<-1;
        else {
            bought[colors[customer].top()] = true;
            out << colors[customer].top();
            colors[customer].pop();
        }
        if(m>=1)out << " ";
    }
    out << endl;
    return 0;
}
