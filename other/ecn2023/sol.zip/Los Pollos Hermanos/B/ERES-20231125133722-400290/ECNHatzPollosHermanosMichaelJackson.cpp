#include <iostream>
#include<vector>
#include<string>
#include<map>
#include <set>
#include<unordered_map>
#include<algorithm>
#include<utility>
#include<stack>
using namespace std;
#define ll long long

int main()
{
    ios_base::sync_with_stdio(NULL), cin.tie(NULL), cout.tie(NULL);
    ll n;
    cin >> n;
    vector<pair<pair<long long, long long>, pair<long long, long long>>>v(n);
    unordered_map<long long, pair<bool, long long>>taken;
    for (long long i = 0; i < n; i++) {
        cin >> v[i].first.first;
        v[i].first.second = i;
        taken[i].first = false;
        taken[i].second = v[i].first.first;
    }
    //sort(v.begin(), v.end());
    for (long long i = 0; i < n; i++) {
        long long x;
        cin >> x;
        v[i].second.first = x;
    }
    for (long long i = 0; i < n; i++) {
        long long x;
        cin >> x;
        v[i].second.second = x;
    }  
    sort(v.begin(), v.end());
    vector<stack<long long>>colors(4);
    for (long long i = n - 1; i >= 0; i--) {
        colors[v[i].second.first].push(v[i].first.second);
        colors[v[i].second.second].push(v[i].first.second);
    }
    long long customers;
    cin >> customers;
    while (customers--) {
        long long customer;
        cin >> customer;
        while (colors[customer].empty()==false&&taken[colors[customer].top()].first == true) {
            colors[customer].pop();
        }
        if (colors[customer].empty() == true)cout << -1 << " ";
        else {
            taken[colors[customer].top()].first = true;
            cout << taken[colors[customer].top()].second << " ";
            colors[customer].pop();
        }
    }
    return 0;
}
