#include <iostream>
#include<vector>
#include<string>
#include<map>
#include<unordered_map>
#include<algorithm>
#include<utility>
#include<stack>
#include<fstream>
using namespace std;
//ifstream in("citire.in");
//ofstream out("afisare.out");
#define ll long long
//struct tc {
//    ll cost;
//    ll face;
//    ll back;
//    bool exist;
//
//};
//int comp(tc a, tc b) {
//    return a.cost < b.cost;
//}
//tc tablecloths[200005];
//ll n, q;
int main()
{
    ios_base::sync_with_stdio(NULL), cin.tie(NULL), cout.tie(NULL);
    string s;
    stack<int>stiva;
    stiva.push(0);
    while (cin >> s) {
        if (s[s.size() - 1] == 'E')break;
        else {
            if (s[s.size() - 1] == 'P')
            {
                int x;
                cin >> x;
                stiva.push(x);
            }
            else if (s[s.size() - 1] == 'A') {
                int nr1 = stiva.top();
                stiva.pop();
                int nr2 = stiva.top();
                stiva.pop();
                stiva.push(nr1 + nr2);
            }
            else if (s[s.size() - 1] == 'S') {
                int nr1 = stiva.top();
                stiva.pop();
                int nr2 = stiva.top();
                stiva.pop();
                stiva.push(nr1 - nr2);
            }
        }
    }
        cout << stiva.top();
        return 0;
}
