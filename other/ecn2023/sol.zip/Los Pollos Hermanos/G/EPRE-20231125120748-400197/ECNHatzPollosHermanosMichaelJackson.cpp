#include <iostream>
#include<vector>
#include<string>
#include<map>
#include<unordered_map>
#include<algorithm>
#include<utility>
#include<stack>
#include<fstream>
using namespace std;
ifstream in("citire.in");
ofstream out("afisare.out");
#define ll long long
//struct tc {
//    ll cost;
//    ll face;
//    ll back;
//    bool exist;
//
//};
//int comp(tc a, tc b) {
//    return a.cost < b.cost;
//}
//tc tablecloths[200005];
//ll n, q;
int main()
{
    ios_base::sync_with_stdio(NULL), cin.tie(NULL), cout.tie(NULL);
    string s;
    stack<ll>stiva;
    while (getline(cin, s))
    {
        char caracter = s[s.find('_')+1];
        ll numar=0;
        if (caracter == 'P') {
            for (int i = s.find('_') + 3; i < s.size(); i++)
                numar = numar * 10 + s[i] - '0';
            stiva.push(numar);         
        }
        else
            if (caracter == 'A')
            {
                ll numar1 = stiva.top();
                stiva.pop();
                ll numar2 = stiva.top();
                stiva.pop();
                stiva.push(numar1 + numar2);
            }
            else if (caracter == 'S')
            {
                ll numar1 = stiva.top();
                stiva.pop();
                ll numar2 = stiva.top();
                stiva.pop();
                stiva.push(numar1 - numar2);
            }
            else
                if (caracter == 'E') {
                    cout << stiva.top();
                    break;
                } 
    }
    return 0;
}
