#include <iostream>
#include<vector>
#include<string>
#include<map>
#include <set>
#include<unordered_map>
#include<algorithm>
#include<utility>
#include<fstream>
#include<stack>
using namespace std;
//ifstream in("citire.in");
//ofstream out("afisare.out");
#define ll long long
ll n, q;

vector<string> noduri;
vector<string> ans;
unordered_map<string, vector<string>> adj;
unordered_map<string, bool> visited;
unordered_map<string, bool> surse;
void dfs(string src) {
    if(visited[src]== true) return;
    visited[src] = true;
    for (auto i : adj[src]) {
        if (visited[i] == false) {
            dfs(i);
        }
    }

}
int main()
{
    ios_base::sync_with_stdio(NULL), cin.tie(NULL), cout.tie(NULL);
    cin >> n>>q;
    string s;
    
    cin.ignore();
    for (ll j = 0; j < n; j++) {
        ll ok = 0;
        getline(cin, s);
        if (s[s.size() - 1] == ':')
            ok = 1;
        string resurse;
        int i = 0;
        for (; i < s.size() && s[i] != ':'; i++)
            resurse.push_back(s[i]);
        i++;
        while (i < s.size())
        {
            i++;
            string cuv;
            while (s[i] != ' ' && i < s.size())
            {
                cuv.push_back(s[i]);
                i++;
            }
            adj[cuv].push_back(resurse);
            
        }
        if (ok) {
            noduri.push_back(resurse);
            surse[resurse] = true;
        }
        else {
            noduri.push_back( resurse);
            surse[resurse] = false;
            }
        

        

        
    }
    while (q--) {
        string k;
        for (ll i = 0; i < n; i++) {
            cin >> k;
            if (visited[k] == false && surse[k] == true) {
                dfs(k);
            }
            else
                if(visited[k]==false&&surse[k]==false){
                    ans.push_back(k);
                }
        }
        if (!ans.empty()) {
            if (ans.size() == 1) {
                cout << "Problematic resource : ";
                cout << ans[0];
            }
            else {
                cout << "Problematic resources : ";
                for (auto i : ans)
                    cout << i << " ";
            }
            cout << endl;
        }
        else
            cout << "No problematic resources."<<endl;
        ans.clear();
        visited.clear();

    }
    return 0;
}
