#include <iostream>
#include <string>
#include <stack>
#include <fstream>

int main() {
    std::stack<int> memory; // A memória verem
    std::string instruction; // Az aktuális utasítás

    std::ifstream fin("input_long.txt");
    if(!fin.is_open()) {std::cout<<"Error opening input file."; return -1;}

    std::ofstream fout("input_long.out");
    if(!fin.is_open()) {std::cout<<"Error opening output file."; return -1;}

    while (fin >> instruction) {
        if (instruction == "TITKOS_P") {
            int x;
            fin >> x;
            memory.push(x); 
        } else if (instruction == "TITKOS_A") {
            int x = memory.top();
            memory.pop();
            int y = memory.top();
            memory.pop();
            memory.push(x + y); 
        } else if (instruction == "TITKOS_S") {
           int x = memory.top();
            memory.pop();
            int y = memory.top();
            memory.pop();
            memory.push(x - y); 
        } else if (instruction == "TITKOS_E") {
            int result = memory.top();
            memory.pop();
            fout << result << std::endl; 
            break;
        }
    }

    fin.close();
    fout.close();
    
    return 0;
}
