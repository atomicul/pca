#include <stdlib.h>
#include <string.h>
#include <stdio.h>

typedef struct {
        int k; char D[12], N[28], a;
        } T_pers;
static T_pers Pers[160004], *Pps;

static int npe;

static int cmpK(const void *A, const void *B) {
T_pers *P = (T_pers *)A, *Q = (T_pers *)B;
return P->k - Q->k;
}

static T_pers *checkList(void) {
static int prt;
T_pers *Ppw;
int k;
if (Pps->k==0) return NULL;
for (Ppw=Pps,k=0; strcmp(Pps->D,Ppw->D)==0; Ppw++)
    if (Ppw->a=='A') k++;
if (k>0) if (Ppw-1>Pps) {
   if (prt) printf("\n");
   for (Ppw=Pps; strcmp(Pps->D,Ppw->D)==0; Ppw++)
       printf("%d %s\n",Ppw->k,Ppw->N);
   prt++;
   }
return Ppw;
}

int main() {
int k;
scanf("%d",&npe);
for (k=0,Pps=Pers; k<npe; k++,Pps++)
    scanf("%d %s %c %[^\n]",&Pps->k,Pps->D,&Pps->a,Pps->N);
qsort(Pers,npe,sizeof(T_pers),cmpK);
for (Pps=Pers; Pps=checkList(); ) ;
return 0;
}
