#include <iostream>
#include <vector>
#include <set>
#include <map>
#include <algorithm>

using namespace std;

int N, M;
vector<int> A, D;
vector<map<int,int>> mp;
vector<set<int>> ts;
vector<vector<int>> divs;

int get_next(int id, int val) {
    auto it = ts[val].lower_bound(id);
    if (it == ts[val].end())
        return M;
    return *it;
}
int dfs(int id, int val) {
    if (id == M) return val;
    if (mp[id].count(val))
        return mp[id][val];
    
    int nxtid = M;
    for (int g : divs[val])
        nxtid = min(nxtid, get_next(id, g));
    if (nxtid == M) return val;
    
    int res = dfs(nxtid + 1, val + 1);
    mp[id][val] = res;
    return res;
}
int main() {
    ios::sync_with_stdio(false);
    cin >> N >> M;
    A.resize(N);
    for (int i=0; i<N; ++i) cin >> A[i];
    D.resize(M);
    for (int i=0; i<M; ++i) cin >> D[i];
    
    mp.resize(M);
    int sz = *max_element(A.begin(), A.end()) + M + 1;
    ts.resize(max(sz, 1 + *max_element(D.begin(), D.end())));
    for (int i=0; i<M; ++i) {
        ts[D[i]].insert(i);
    }
    divs.assign(sz, {});
    for (int i=2; i<sz; ++i) {
        for (int j=i; j<sz; j+=i)
            divs[j].push_back(i);
    }

    long long ans = 0ll;
    for (int i=0; i<N; ++i) {
        ans += dfs(0, A[i]) - A[i];
    }
    cout << ans << endl;

    return 0;
}
