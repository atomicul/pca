#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int T;
string s;
vector<int> cnt;

void solve() {
    cin >> s;
    cnt.assign(26, 0);
    for (char c : s) ++cnt[c-'a'];
    sort(cnt.begin(), cnt.end());
    int ans = 0;
    for (int i=0; i+2<26; ++i) {
        ans += cnt[i];
    }
    cout << ans << endl;
}
int main() {
    ios::sync_with_stdio(false);
    for (cin >> T; T--;) solve();
    return 0;
}
