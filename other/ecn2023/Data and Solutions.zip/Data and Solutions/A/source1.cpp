#include <iostream>
#include <fstream>
#include <algorithm>
#include <set>
#include <string>
#include <vector>
#define pb push_back
#define MAX 200005

using namespace std;

struct A
{
	int nvl, nod;
};
vector < A > rmq[20];

set < int > fr;
vector < int > v[MAX], a, b, euler;
int dif[MAX], val[MAX], prim[MAX], nvl[MAX], inceput[MAX], finall[MAX];

void dfs(int nod, int prec);
int LCA(int x, int y);

int main()
{


	int n, q, x, y, s, k;
	cin >> n >> q;
	for (int i = 1; i <= n; i++) cin >> dif[i];
	for (int i = 1; i < n; i++) cin >> x >> y, v[x].pb(y), v[y].pb(x);
	for (int i = 1; i <= n; ++i) {
		sort(v[i].begin(), v[i].end());
	}
	a.pb(0), dfs(1, 0);

	x = euler.size(), y = log2(x);
	for (auto it : euler) rmq[0].pb({ nvl[it], it });
	for (int i = 1; i <= y; i++)
		for (int j = 0; j < x - ((1 << i) - 1); j++)
			if (rmq[i - 1][j].nvl < rmq[i - 1][j + (1 << (i - 1))].nvl) rmq[i].pb(rmq[i - 1][j]);
			else rmq[i].pb(rmq[i - 1][j + (1 << (i - 1))]);

	while (q--)
	{
		cin >> s >> k, b.clear(), fr.clear();
		for (int i = 1; i <= k; i++) cin >> x, b.pb(x), s -= val[x], fr.insert(x);

		int lca = b[0];
		for (int i = 1; i < b.size(); i++) lca = LCA(lca, b[i]);

		int st = inceput[lca], dr = finall[lca], r = st;
		while (st <= dr)
		{
			int mij = (st + dr) / 2;
			if (val[a[mij]] < s) r = mij, st = mij + 1;
			else dr = mij - 1;
		}
		st = r, dr = r + 1;
		while (st >= inceput[lca] && fr.find(a[st]) != fr.end()) st--;
		while (dr <= finall[lca] && fr.find(a[dr]) != fr.end()) dr++;

		if (st == inceput[lca] - 1) cout << a[dr] << ' ';
		else if (dr == finall[lca] + 1) cout << a[st] << ' ';
		else
		{
			if ((abs(s - val[a[st]]) < abs(s - val[a[dr]])) || (abs(s - val[a[st]]) == abs(s - val[a[dr]]) && a[st] < a[dr])) cout << a[st] << ' ';
			else cout << a[dr] << ' ';
		}
	}


	return 0;
}

void dfs(int nod, int prec)
{
	euler.pb(nod), nvl[nod] = nvl[prec] + 1;
	prim[nod] = euler.size() - 1;

	val[nod] = val[a.back()] + dif[a.size()], a.pb(nod), inceput[nod] = a.size() - 1;
	for (int x : v[nod]) if (x != prec) dfs(x, nod), euler.pb(nod);
	finall[nod] = a.size() - 1;
}

int LCA(int x, int y)
{
	x = prim[x], y = prim[y];
	if (x > y) swap(x, y);

	int n = log2(y - x + 1);
	if (rmq[n][x].nvl < rmq[n][y - (1 << n) + 1].nvl) return rmq[n][x].nod;
	else return rmq[n][y - (1 << n) + 1].nod;
}