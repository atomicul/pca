#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include <string>
#include <algorithm>

using namespace std;

int n, q, timp;

int d[200005];
int anc[200005][22];
vector<int> v[200005];

int st[200005];
int dr[200005];

bool on[200005];
int inv[200005];
int val[200005];


int ancF(int p, int d)
{
	for (int b = 0; b <= 20; b++)
		if ((d >> b) & 1)
			p = anc[p][b];

	return p;
}

int lcaF(int x, int y)
{
	if (d[x] > d[y])
		swap(x, y);

	y = ancF(y, d[y] - d[x]);

	if (x == y)
		return x;

	for (int b = 20; b >= 0; b--)
		if (anc[x][b] != anc[y][b])
		{
			x = anc[x][b];
			y = anc[y][b];
		}

	return anc[x][0];
}

void dfs(int p, int par)
{
	d[p] = d[par] + 1;

	anc[p][0] = par;
	for (int b = 1; b <= 20; b++)
		anc[p][b] = anc[anc[p][b - 1]][b - 1];

	timp++;
	st[p] = timp;
	inv[timp] = p;

	sort(v[p].begin(), v[p].end());

	for (int it : v[p])
	{
		if (it == par)
			continue;

		dfs(it, p);
	}

	dr[p] = timp;
}

int solve(int l, int r, int tgVal)
{
	int p = lower_bound(val + l, val + r + 1, tgVal) - val;

	int bestDif = 1e9;
	int bestNode = 0;

	for (int i = max(p - 10, l); i <= min(p + 10, r); i++)
	{
		if (!on[i])
			continue;

		int nDif = abs(val[i] - tgVal);

		if (nDif < bestDif)
		{
			bestDif = nDif;
			bestNode = inv[i];
		}
		else if (nDif == bestDif && inv[i] < bestNode)
			bestNode = inv[i];
	}

	return bestNode;
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(0);

	cin >> n >> q;

	for (int i = 1; i <= n; i++)
	{
		cin >> val[i];
		val[i] += val[i - 1];

		on[i] = true;
	}

	for (int i = 1; i < n; i++)
	{
		int x, y;
		cin >> x >> y;

		v[x].push_back(y);
		v[y].push_back(x);
	}

	dfs(1, 0);

	while (q)
	{
		q--;

		int sum, k;
		cin >> sum >> k;

		vector<int> mem;
		for (int i = 1; i <= k; i++)
		{
			int x;
			cin >> x;

			mem.push_back(x);
			sum -= val[st[x]];
		}


		int lca = mem[0];
		for (int it : mem)
			lca = lcaF(lca, it);

		//cout<<lca<<'\n';

		for (int it : mem)
			on[st[it]] = false;

		cout << solve(st[lca], dr[lca], sum) << ' ';

		for (int it : mem)
			on[st[it]] = true;
	}



	return 0;
}
