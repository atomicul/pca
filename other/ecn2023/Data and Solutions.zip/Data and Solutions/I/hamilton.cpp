#include <fstream>
#include <iostream>
#include <algorithm>
#include <cmath>

using namespace std;
ifstream fin("hamilton.in");
ofstream fout("hamilton.out");
double d[3009][3009];
struct point
{
    int x,y;
};
double dist(point u, point v)
{
    double d, x1, y1, x2, y2;
    x1=u.x;
    y1=u.y;
    x2=v.x;
    y2=v.y;
    d=sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
    return d;
}
bool criteriu(point u, point v)
{
    return u.x<v.x;
}
int main()
{
    int n;
    point a[3009];

    fin>>n;
    for(int i=0;i<n;i++)
        fin>>a[i].x>>a[i].y;

    sort(a,a+n,criteriu);

///    fout<<n<<endl;
///    for(int i=0;i<n;i++)
///        fout<<a[i].x<<" "<<a[i].y<<endl;
    for(int i=0;i<n;i++)
        for (int j=0;j<n;j++)
            if(i==j)
                d[i][j]=0;
            else
                if(i>j)
                    d[i][j]=d[j][i];
                else
                    if(i==0 or j-i>1)
                        d[i][j]=d[i][j-1]+dist(a[j-1],a[j]);
                    else
                        {
                            double mini=2000000000;
                            for(int k=0;k<i;k++)
                            {
                                double nextv=d[i][k]+dist(a[k],a[j]);
                                if(nextv<mini)
                                    mini=nextv;
                            }
                            d[i][j]=mini;
                        }
///    cout<<n<<endl;
///    for(int i=0;i<n;i++)
///    {
///        for(int j=0;j<n;j++)
///            cout<<d[i][j]<<" ";
///        cout<<"\n";
///    }

    double mini=2000000000;
    for (int i=0;i<n-1;i++)
    {
        double nextv=d[i][n-1]+dist(a[i],a[n-1]);
        if(nextv<mini)
            mini=nextv;
    }
    long long rez=mini;
    mini=mini-rez;
    long long dec=mini*1000000;
    fout<<rez<<"."<<dec;
    return 0;
}
