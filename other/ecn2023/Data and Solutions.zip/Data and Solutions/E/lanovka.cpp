#include <bits/stdc++.h>
#include <iostream>
#include <fstream>

using namespace std;

const long long maxn = 2e5;
const long long inf = 1e16 + 42;

long long n, k;
long long val[maxn + 1];
long long tree_max[4 * (maxn + 1) + 1];
long long tree_sum[4 * (maxn + 1) + 1];

ifstream be("F.in");

void build(long long v, long long vl, long long vr) {
    if(vl == vr) {
        tree_max[v] = tree_sum[v] = val[vl];
        return;
    }
    long long mid = (vl + vr) / 2;
    build(2 * v, vl, mid);
    build(2 * v + 1, mid + 1, vr);
    tree_max[v] = max(tree_max[2 * v], tree_max[2 * v + 1]);
    tree_sum[v] = tree_sum[2 * v] + tree_sum[2 * v + 1];
}

long long query_max(long long v, long long vl, long long vr, long long ql, long long qr) {
    if(ql > vr || qr < vl) {
        return 0;
    }
    if(vl == ql && vr == qr) {
        return tree_max[v];
    }
    long long mid = (vl + vr) / 2;
    return max(query_max(2 * v, vl, mid, ql, min(qr, mid)), query_max(2 * v + 1, mid + 1, vr, max(ql, mid + 1), qr));
}

long long query_sum(long long v, long long vl, long long vr, long long ql, long long qr) {
    if(ql > vr || qr < vl) {
        return 0;
    }
    if(vl == ql && vr == qr) {
        return tree_sum[v];
    }
    long long mid = (vl + vr) / 2;
    return query_sum(2 * v, vl, mid, ql, min(qr, mid)) + query_sum(2 * v + 1, mid + 1, vr, max(ql, mid + 1), qr);
}

void solve() {
    be >> n >> k;
    for(long long i = 1; i <= n; i++) {
        be >> val[i];
        val[i] += i;
    }
    build(1, 1, n);
    long long ans = inf;
    for(long long i = 1; i + k - 1 <= n; i++) {
        long long all = k * query_max(1, 1, n, i, i + k - 1);
        long long have = query_sum(1, 1, n, i, i + k - 1);
        long long needed = all - have;
        ans = min(ans, needed);
    }
    cout << ans << "\n";
}

signed main() {
    int T;
    be >> T;
    for(int i = 0; i < T; ++i)
       solve();
    be.close();
    return 0;
}
