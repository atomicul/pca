#include <iostream>
#include <fstream>
#include <set>

using namespace std;
int main() {
    long time_begin = clock();
//    ifstream fin("test_200000_200000.in");
//    ofstream fout("test_200000_200000.out");

    ifstream fin("test_5_5.in");
    ofstream fout("test_5_5.out");
    if (!fin.is_open()) {
        cout << "Unable to open file" << endl;
        exit( 1 );
    }
    int n;
    fin >> n;
    long prices[200000];
    set<long> colors[4];
    for (int i = 0; i < n; ++i) {
        fin >> prices[i];
    }
    int color;
    for (int i = 0; i < n; ++i) {
        fin >> color;
        colors[color].insert(prices[i]);
    }
    for (int i = 0; i < n; ++i) {
        fin >> color;
        colors[color].insert(prices[i]);
    }
    int m;
    fin >> m;
    cout << "Ready to process" << endl;
    for (int i = 0; i < m; ++i) {
        fin >> color;
        if (colors[color].size() == 0) {
            fout << "-1 ";
            continue;
        }
        set<long>::iterator it = colors[color].begin();
        long price = *it;
        fout << price << " ";
        for(int j=1; j<4; ++j) {
            colors[j].erase(price);
        }

    }
    long time_end = clock();
    cout << "\nSeconds: " << (time_end - time_begin) / (double) CLOCKS_PER_SEC  << endl;
    return 0;
}
