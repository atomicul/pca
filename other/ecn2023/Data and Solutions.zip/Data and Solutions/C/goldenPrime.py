from sympy import isprime

def goldPrime2Pow(N = 1 << 1000):
    n = 0
    while True:
        phi = 2**n
        q = phi**2 - phi - 1
        if q > N: break
        if isprime(q):
            print(n)
        n += 1

