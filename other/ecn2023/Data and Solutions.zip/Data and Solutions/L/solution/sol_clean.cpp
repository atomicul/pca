#include <iostream>
#include <fstream>
#include <queue>
#include <iomanip>
#include <string>
#include <ctime>
#define LL unsigned long long int

using namespace std;

LL kicsi1[500002], nagy1[500002];
LL kicsi2[500002], nagy2[500002];
int nk1,nk2, nn1, nn2;

void pb_max(LL kicsi[], int &n, LL x){
    kicsi[n++] = x;
    int i = n-1;
    while (i > 0 && kicsi[(i-1)>>1] < x){
        kicsi[i] = kicsi[(i-1)>>1];
        kicsi[(i-1)>>1] = x;
        i = (i-1)>>1;
    }
}

void hp_max(LL kicsi[], int n, int i){
    bool was_switch = true;
    while (was_switch){
        was_switch = false;
        int maxx = i;
        if ((i<<1) + 1 < n && kicsi[(i<<1) + 1] > kicsi[maxx])
                maxx = (i<<1) + 1;
        if ((i<<1) + 2 < n && kicsi[(i<<1) + 2] > kicsi[maxx])
            maxx = (i<<1) + 2;            
        if (maxx != i){
            LL t = kicsi[i];
            kicsi[i] = kicsi[maxx];
            kicsi[maxx] = t;
            was_switch = true;
        }
        i = maxx;
    }
}

void pop_max(LL kicsi[], int &n){
    kicsi[0] = kicsi[--n];
    hp_max(kicsi, n, 0);
}

LL top_max(LL kicsi[], int n){
    return kicsi[0];
}

void pb_min(LL kicsi[], int &n, LL x){
    kicsi[n++] = x;
    int i = n-1;
    while (i > 0 && kicsi[(i-1)>>1] > x){
        kicsi[i] = kicsi[(i-1)>>1];
        kicsi[(i-1)>>1] = x;
        i = (i-1)>>1;
    }
}

void hp_min(LL kicsi[], int n, int i){
    bool was_switch = true;
    while (was_switch){
        was_switch = false;
        int maxx = i;
        if ((i<<1) + 1 < n && kicsi[(i<<1) + 1] < kicsi[maxx])
                maxx = (i<<1) + 1;
        if ((i<<1) + 2 < n && kicsi[(i<<1) + 2] < kicsi[maxx])
            maxx = (i<<1) + 2;            
        if (maxx != i){
            LL t = kicsi[i];
            kicsi[i] = kicsi[maxx];
            kicsi[maxx] = t;
            was_switch = true;
        }
        i = maxx;
    }
}

void pop_min(LL kicsi[], int &n){
    kicsi[0] = kicsi[--n];
    hp_min(kicsi, n, 0);
}

LL top_min(LL kicsi[], int n){
    return kicsi[0];
}

LL mx = 0;

void insert(LL x, int line){
    mx = max(mx, x);
    if (line){
        if (!nk2 || x<top_max(kicsi2,nk2))
            pb_max(kicsi2,nk2,x);
        else   
            pb_min(nagy2,nn2,x);

        if (nk2 > nn2 + 1){
            x=top_max(kicsi2,nk2);
            pop_max(kicsi2,nk2);
            pb_min(nagy2,nn2,x);
        } else if (nn2 > nk2 + 1){
            x=top_min(nagy2,nn2);
            pop_min(nagy2, nn2);
            pb_max(kicsi2,nk2,x);
        }
    }
    else{
        if (!nk1 || x<top_max(kicsi1,nk1))
            pb_max(kicsi1,nk1,x);
        else   
            pb_min(nagy1,nn1,x);

        if (nk1 > nn1 + 1){
            x=top_max(kicsi1,nk1);
            pop_max(kicsi1,nk1);
            pb_min(nagy1,nn1,x);
        } else if (nn1 > nk1 + 1){
            x = top_min(nagy1,nn1);
            pop_min(nagy1,nn1);
            pb_max(kicsi1,nk1,x);
        }
    }

}

LL popped[10];
int poppedCount;

LL pop_from1(bool isSmall, int n){
    poppedCount = 0;
    LL ret;
    if (isSmall){
        while (poppedCount<n && nk1){
            popped[poppedCount++] = top_max(kicsi1,nk1);
            pop_max(kicsi1,nk1);
        }
        ret = (poppedCount == n && nk1) ? top_max(kicsi1,nk1) : 0;
        while (poppedCount){
            pb_max(kicsi1,nk1,popped[--poppedCount]);
        }
    }
    else {
        while (poppedCount<n && nn1){
            popped[poppedCount++] = top_min(nagy1,nn1);
            pop_min(nagy1,nn1);
        }
        ret = (poppedCount == n && nn1) ? top_min(nagy1,nn1) : 0;
        while (poppedCount){
            pb_min(nagy1,nn1,popped[--poppedCount]);
        }
    }
    return ret;
}

LL pop_from2(bool isSmall, int n){
    poppedCount = 0;
    LL ret;
    if (isSmall){
        while (poppedCount<n && nk2){
            popped[poppedCount++] = top_max(kicsi2,nk2);
            pop_max(kicsi2,nk2);
        }
        ret = (poppedCount == n && nk2) ? top_max(kicsi2,nk2) : 0;
        while (poppedCount){
            pb_max(kicsi2,nk2,popped[--poppedCount]);
        }
    }
    else {
        while (poppedCount<n && nn2){
            popped[poppedCount++] = top_min(nagy2,nn2);
            pop_min(nagy2,nn2);
        }
        ret = (poppedCount == n && nn2) ? top_min(nagy2,nn2) : 0;
        while (poppedCount){
            pb_min(nagy2,nn2,popped[--poppedCount]);
        }
    }
    return ret;
}

int draw(int offset, LL rotationCount){
    LL ret;
    bool rotated = rotationCount & 1; 
    if (offset>0){
        if (nn1>=nk1) ret = pop_from1(false,offset);
        else ret = pop_from1(false,offset-1);
        if (!rotated){
            if (nn2>=nk2) ret += pop_from2(false,offset);
            else ret += pop_from2(false,offset-1);
        }
        else {
            if (nk2>=nn2) ret += pop_from2(true,offset);
            else ret += pop_from2(true,offset-1);
        }
    } else {
        if (offset == 0){
            if (nn1>=nk1) ret = pop_from1(false,0);
            else ret = pop_from1(true,0);
            if (!rotated) {
                if (nn2>=nk2) ret += pop_from2(false,0);
                else ret += pop_from2(true,0);
            } else {
                if (nk2>=nn2) ret += pop_from2(true,0);
                else ret += pop_from2(false,0);
            }
        }
        else{
            if (nk1>=nn1) ret = pop_from1(true,-offset);
                else ret = pop_from1(true,-offset-1);
                if (!rotated){
                    if (nk2>=nn2) ret += pop_from2(true,-offset);
                    else ret += pop_from2(true,-offset-1);
                } else {
                    if (nn2>=nk2) ret += pop_from2(false,-offset);
                    else ret += pop_from2(false,-offset-1);
                }
        }
    }

    return ret % mx;
}

int main(){
    LL a=2,b=3,c=4,d=1000007, value=11111025;
    int line=123, k=8;
    int la=123, lb=1123, lc=123, ld=3;
    int n=1000000;
	LL op = 22;

	cin >> a >> b >> c >> d >> value;
	cin >> la >> lb >> lc >> ld >> op;
	cin >> k >> n;
	
	while (n)
	{
		op = (((la*op + lb)*lc)+ld) % 1000000007;
        line = op % 3 + 1;

		value = ((a*value + b)*c % d);
		if (line == 3) 
		{
			if (!(n&1)){
				k = (((k*la+lb)*lc)+ld)%21-10;
				cout << draw(k,value) << endl;
			}
		}
		else 
		{
			insert(value, line - 1);
			n--;
		}
	}

	value = ((a*value + b)*c % d);
	k = (((k*la+lb)*lc)+ld)%21-10;
	cout << draw(k,value) << endl;

    return 0;
}