#include <iostream>
#include <vector>

using namespace std;

const int ILLEGAL_VALUE = 1e9;
int R, C, P;
vector<vector<int>> elevations;
vector<vector<vector<int>>> DP;

bool is_pass(int r, int c) {
  if (r == 0 || c == 0 || r == R-1 || c == C-1)
    return false;
  if (elevations[r][c] == -1 || elevations[r-1][c] == -1 ||
     elevations[r+1][c] == -1 || elevations[r][c-1] == -1 ||
     elevations[r][c+1] == -1)
    return false;
  if (elevations[r-1][c] > elevations[r][c] &&
     elevations[r+1][c] > elevations[r][c] &&
     elevations[r][c-1] < elevations[r][c] &&
     elevations[r][c+1] < elevations[r][c])
    return true;
  else
    return false;
}

int solve(int r, int c, int p) {
  if (p < 0)
    return ILLEGAL_VALUE;
  if (c == C-1) {
    if(p == 0)
      return 0;
    else
      return ILLEGAL_VALUE;
  }
  if(DP[r][c][p] != -2)
    return DP[r][c][p];

  // NE
  int best_score = ILLEGAL_VALUE;
  int cur;
  if (r > 0 && elevations[r-1][c+1] != -1) {
    if (is_pass(r-1, c+1))
      cur = solve(r-1, c+1, p-1) + elevations[r-1][c+1];
    else
      cur = solve(r-1, c+1, p) + elevations[r-1][c+1];
    if (cur < best_score)
      best_score = cur;
  }
  // E
  if (elevations[r][c+1] != -1) {
    if (is_pass(r, c+1))
      cur = solve(r, c+1, p-1) + elevations[r][c+1];
    else
      cur = solve(r, c+1, p) + elevations[r][c+1];
    if (cur < best_score)
      best_score = cur;
  }
  // SE
  if (r < R-1 && elevations[r+1][c+1] != -1) {
    if (is_pass(r+1, c+1))
      cur = solve(r+1, c+1, p-1) + elevations[r+1][c+1];
    else
      cur = solve(r+1, c+1, p) + elevations[r+1][c+1];
    if (cur < best_score)
      best_score = cur;
  }

  if(best_score > ILLEGAL_VALUE)
    best_score = ILLEGAL_VALUE;
  DP[r][c][p] = best_score;
  return best_score;
}

int main() {
  ios::sync_with_stdio(false);
  cin >> R >> C >> P;
  elevations.assign(R, vector<int>(C, 0));
  for (int i = 0; i < R; ++i) {
    for (int j = 0; j < C; ++j)
      cin >> elevations[i][j];
  }

  int best_path = ILLEGAL_VALUE;
  DP.assign(R, vector<vector<int>>(C, vector<int>(P+1, -2)));
  for (int start_row = 0; start_row < R; ++start_row) {
    if (elevations[start_row][0] != -1) {
      int cur = elevations[start_row][0] + solve(start_row, 0, P);
      if (cur < best_path)
        best_path = cur;
    }
  }
  
  if (best_path < ILLEGAL_VALUE)
    cout << best_path << endl;
  else
    cout << "impossible" << endl;
  
  return 0;
}
