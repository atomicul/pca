#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define N 102

int currentLevel( int k, int m, int a[][N], int b[][N] );
bool hasNeighborB( int i, int j, int k, int b[][N] );
void printMatrix( int m, int x[][N] );
void initMatrixB( int k, int m, int a[][N], int b[][N] );

int main()
{
    int t,n,m,a[N][N]={0},b[N][N]={0};
    freopen("KZinput.txt","r",stdin);
    freopen("KZoutput.txt","w",stdout);
    scanf("%i", &t);
    for( int c = 0 ; c < t ; ++c ){
        scanf("%i%i", &n, &m);
        for( int i = 0 ; i <= m+1 ; ++i ){
            for( int j = 0 ; j <= m+1 ; ++j ){
                a[i][j] = 0;
            }
        }
        for( int k = 0 ; k < n ; ++k ){
            for( int i = 1 ; i <= m ; ++i ){
                for( int j = 1 ; j <= m ; ++j ){
                    int x; scanf("%3i", &x);
                    a[i][j] += x;
                }
            }
        }
        //printMatrix(m,a);

        int unsafeSteps = 0;
        for( int k = 1 ; k < n ; ++k ){ //level by level
            initMatrixB(k,m,a,b); //(-1) for all external points , (-2) for all internal points
            unsafeSteps += currentLevel(k,m,a,b);// unsafe steps at the current level
        }

        printf("%i\n", unsafeSteps);
    }

    return 0;
}

void printMatrix( int m, int x[][N] ){
    printf("\n");
    for( int i = 0 ; i <= m+1 ; ++i ){
        for( int j = 0 ; j <= m+1 ; ++j ){
            printf("%i", x[i][j]);
        }
        printf("\n");
    }
}

void initMatrixB( int k, int m, int a[][N], int b[][N] ){
    for( int i = 0 ; i <= m+1 ; ++i ){
        for( int j = 0 ; j <= m+1 ; ++j ){
            if( a[i][j] < k ){ b[i][j] = -1; }
            else{ b[i][j] = -2; }
        }
    }
}

int currentLevel( int k, int m, int a[][N], int b[][N] ){

    int kk = 0;
    while( 1 ){
        //identifying kk-distant mountain-points from the boundary of level k
        for( int i = 1 ; i <= m ; ++i ){
            for( int j = 1 ; j <= m ; ++j ){
                if( a[i][j] == k+1 && b[i][j] == -2 && hasNeighborB(i,j,kk-1,b) ){
                    //the boundary of the next level was reached by kk steps
                    return kk;
                }
                if( a[i][j] == k && b[i][j] == -2 && hasNeighborB(i,j,kk-1,b) ){
                    b[i][j] = kk;
                }
            }
        }
        ++kk;
    }
}

bool hasNeighborB( int i, int j, int k, int b[][N] ){
    int di[] = {+1,0,-1,0};
    int dj[] = {0,+1,0,-1};
    for( int p = 0 ; p < 4 ; ++p ){
        if( b[i + di[p]][j + dj[p]] == k ){
            return true;
        }
    }
    return false;
}
